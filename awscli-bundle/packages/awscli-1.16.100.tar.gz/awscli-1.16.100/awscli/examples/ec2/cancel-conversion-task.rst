**To cancel an active conversion of an instance or a volume**

This example cancels the upload associated with the task ID import-i-fh95npoc. If the command succeeds, no output is returned.

Command::

  aws ec2 cancel-conversion-task --conversion-task-id import-i-fh95npoc
