**To delete user attributes**

This example deletes the user attribute "FAVORITE_ANIMAL".

Command::

  aws cognito-idp delete-user-attributes --access-token ACCESS_TOKEN --user-attribute-names "FAVORITE_ANIMAL"
  
